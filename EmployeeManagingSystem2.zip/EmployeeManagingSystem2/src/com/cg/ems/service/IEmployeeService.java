package com.cg.ems.service;

import java.util.List;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;

public interface IEmployeeService {

	public boolean add(Employee emp)throws EmployeeException;
	public boolean remove(int empId)throws EmployeeException;
	public Employee get(int empId) throws EmployeeException;
	public List<Employee> getAll() throws EmployeeException;
}
