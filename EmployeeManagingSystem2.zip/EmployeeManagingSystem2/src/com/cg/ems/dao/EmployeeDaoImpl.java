package com.cg.ems.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.ems.dto.Employee;
import com.cg.ems.dto.Gender;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.ConnectionProvider;

public class EmployeeDaoImpl implements IEmployeeDao {

	private Logger classLogger;
	private ConnectionProvider conPro;

	public EmployeeDaoImpl() throws EmployeeException {
		classLogger = Logger.getLogger(EmployeeDaoImpl.class);
		try {
			conPro = ConnectionProvider.getInstance("res/jdbc.properties");
		} catch (ClassNotFoundException | IOException exp) {
			classLogger.error(exp);
			throw new EmployeeException("Data Access Initiation Failed!");
		}
	}

	public Employee mapRow(ResultSet row) throws EmployeeException {
		Employee emp = new Employee();
		try {
			emp.setEmpId(row.getInt("empId"));
			emp.setEmpName(row.getString("empName"));
			emp.setGender(Gender.valueOf(row.getString("gender")));
			emp.setBasic(row.getDouble("basic"));

		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new EmployeeException("Failed to retrieve data!");
		}
		return emp;
	}

	public boolean add(Employee emp) throws EmployeeException {
		boolean result = false;
		if (emp != null) {
			try (Connection con = conPro.getConnection();
					PreparedStatement pstInsert = con
							.prepareStatement(IQueryMapper.INSERT_EMP_QRY)) {
				classLogger.debug(emp + "being added!");
				pstInsert.setString(1, emp.getEmpName());
				pstInsert.setString(2, emp.getGender().toString());
				pstInsert.setDouble(3, emp.getBasic());
				
				classLogger.debug("4 values are added to pst insert");
				int count = pstInsert.executeUpdate();
				if (count > 0) {
					result = true;
				}
			} catch (SQLException exp) {
				classLogger.error(exp);
				throw new EmployeeException("Failed to add record!");
			}
		}
		return result;
	}
	@Override
	public boolean remove(int empId) throws EmployeeException {
		boolean result = false;
		try (Connection con = conPro.getConnection();
				PreparedStatement pstDelete = con
				.prepareStatement(IQueryMapper.DELETE_EMP_QRY)) {
			
			pstDelete.setInt(1, empId);
			int count = pstDelete.executeUpdate();
			if (count > 0) {
				result = true;
			}
		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new EmployeeException("Failed to Delete record!");
		}
		return result;
	}

	@Override
	public Employee get(int empId) throws EmployeeException {
		Employee emp = null;
		try (Connection con = conPro.getConnection();
				PreparedStatement pstSelectById = con
				.prepareStatement(IQueryMapper.SELECT_EMP_BY_ID_QRY)) {
			
			pstSelectById.setInt(1, empId);
			ResultSet result = pstSelectById.executeQuery();
			if (result.next())
				emp = mapRow(result);
		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new EmployeeException("Failed to get record!");
		}
		return emp;
	}

	@Override
	public List<Employee> getAll() throws EmployeeException {
		List<Employee> contactsList = new ArrayList<>();
		try (Connection con = conPro.getConnection();
				PreparedStatement pstSelectAll = con
					.prepareStatement(IQueryMapper.SELECT_ALL_EMP_QRY)) {
			
			ResultSet results = pstSelectAll.executeQuery();
			while (results.next()) {
				contactsList.add(mapRow(results));
			}
		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new EmployeeException("Failed to retreive record!");
		}
		return contactsList;
	}

}
