package com.cg.ems.dao;

public interface IQueryMapper {

	public static final String INSERT_EMP_QRY =
			"INSERT INTO EmployeeDet VALUES(empIdSeq.nextval,?,?,?)";
	
	public static final String DELETE_EMP_QRY=
			"DELETE FROM EmployeeDet WHERE empId=?";
	
	public static final String SELECT_EMP_BY_ID_QRY=
			"SELECT * FROM EmployeeDet WHERE empId=?";
	
	public static final String SELECT_ALL_EMP_QRY =
			"SELECT * FROM EmployeeDet";
}
