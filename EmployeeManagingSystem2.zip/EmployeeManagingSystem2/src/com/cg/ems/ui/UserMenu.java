package com.cg.ems.ui;

public enum UserMenu {
	ADD,SEARCH,LIST,DELETE,QUIT;
}
