package com.cg.ems.ui;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.cg.ems.dto.Employee;
import com.cg.ems.dto.Gender;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmployeeServiceImpl;
import com.cg.ems.service.IEmployeeService;

public class EmployeeApp {

	static IEmployeeService service;
	static Scanner scan;

	public static void main(String[] args) {

		PropertyConfigurator.configure("res/log4j.properties");
		try {
			service = new EmployeeServiceImpl();
			System.out.println("Service Started!");
		} catch (EmployeeException exp) {
			System.err.println(exp.getMessage());
			System.exit(0);
		}

		UserMenu choice = null;
		scan = new Scanner(System.in);

		while (choice != UserMenu.QUIT) {

			System.out.println("********* CONTACT BOOK **********");
			System.out.println("CHOICE\t MENU");
			System.out.println("==========================");
			for (UserMenu menuItem : UserMenu.values()) {
				System.out.println(menuItem.ordinal() + "\t" + menuItem.name());
			}

			System.out.println("Enter Choice: ");
			int ordinal = scan.nextInt();

			if (ordinal < 0 || ordinal > UserMenu.QUIT.ordinal()) {
				System.err.println("Invalid Choice...");
				continue;
			}

			choice = UserMenu.values()[ordinal];

			switch (choice) {
			case ADD:
				doAdd();
				break;
			case SEARCH:
				doSearch();
				break;
			case LIST:
				doList();
				break;
			case DELETE:
				doDelete();
				break;
			case QUIT:
				System.out.println("Thank You!");
				break;
			}
		}
		scan.close();
	}

	public static void doAdd() {
		Employee emp = new Employee();

		System.out.println("Enter First Name: ");
		emp.setEmpName(scan.next());
		System.out.println("Enter Gender(" + Arrays.toString(Gender.values())
				+ "):");
		emp.setGender(Gender.valueOf(scan.next().toUpperCase()));
		System.out.println("Enter your Basic Salary : ");
		emp.setBasic(scan.nextDouble());

		try {
			boolean isSuccessful = service.add(emp);
			if (isSuccessful)
				System.out.println("Employee successfully added!");
			else
				System.out.println("Employee could not be added!");
		} catch (EmployeeException exp) {
			System.err.println(exp.getMessage());
		}
	}

	public static void doSearch() {
		System.out.print("Enter Employee Id: ");
		int empId = scan.nextInt();
		try {
			Employee emp = service.get(empId);
			if (emp == null) {
				System.out.println("Employee Not Found!");
			} else {
				System.out.println(emp);
			}
		} catch (EmployeeException exp) {
			System.err.println(exp.getMessage());
		}
	}

	public static void doDelete() {
		try {
			System.out.println("Enter ContactId: ");
			int empId = scan.nextInt();
			Employee emp = service.get(empId);
			if (emp == null) {
				System.out.println("Contact Not Found!");
			} else {
				boolean isSuccessful = service.remove(emp.getEmpId());
				if (isSuccessful)
					System.out.println("Contact deleted!");
				else
					System.out.println("Contact could not be deleted!");
			}
		} catch (EmployeeException exp) {
			System.out.println(exp.getMessage());
		}
	}

	public static void doList() {
		try {
			List<Employee> emps = service.getAll();
			for (Employee emp : emps) {
				System.out.println(emp);
			}
		} catch (EmployeeException exp) {
			System.err.println(exp.getMessage());
		}
	}
}
