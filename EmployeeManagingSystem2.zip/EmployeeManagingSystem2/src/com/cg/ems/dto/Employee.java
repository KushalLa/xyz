package com.cg.ems.dto;

import com.cg.ems.dto.Gender;

public class Employee {

	private int empId;
	private String empName;
	private Gender gender;
	private double basic;
	public Employee() {
		super();
	}
	public Employee(int empId, String empName, Gender gender, double basic) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.gender = gender;
		this.basic = basic;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public double getBasic() {
		return basic;
	}
	public void setBasic(double basic) {
		this.basic = basic;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName
				+ ", gender=" + gender + ", basic=" + basic + "]";
	}
	
	
}
