package com.cg.ems.dto;

public enum Gender {
	MALE, FEMALE;
}
