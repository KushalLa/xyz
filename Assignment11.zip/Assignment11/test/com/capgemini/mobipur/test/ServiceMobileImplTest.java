package com.capgemini.mobipur.test;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.mobipur.bean.MobileBean;
import com.capgemini.mobipur.exception.MobilePurchaseException;
import com.capgemini.mobipur.service.IServiceMobile;
import com.capgemini.mobipur.service.ServiceMobileImpl;

public class ServiceMobileImplTest {
	private IServiceMobile ServicePurchaseMobile;
	
	@Before
	public void setUp() throws Exception {
		ServicePurchaseMobile = new ServiceMobileImpl();
		
	}

	@After
	public void tearDown() throws Exception {
		ServicePurchaseMobile = null;
	}

	@Test
	public final void testSearch() {
		try{
			
		List<MobileBean>mobileList = ServicePurchaseMobile.search(15000, 38000);
		assertTrue("No such mobile",mobileList.size()>0);
	}catch(MobilePurchaseException e){
		e.printStackTrace();
		}
	}
}
